## STATUS: COMPLETE
## SUMMARY: 20 programs identified across 7 categories (+2 checked-but-ineligible flagged). ~$23,800/yr in readily-accessible benefits (up to ~$53,800/yr with contingent childcare + housing). #1 action: enroll BOTH kids in free Medi-Cal now (year-round, covers the 4-yo's asthma — ER, urgent care, inhalers, $0 copay).

## Household Profile
- **Who:** Single parent (head of household) + 2 children, ages **4 and 9**. **Household size = 3.**
- **Income:** **$42,000/year** (~$3,500/month). Income type not specified — assumed earned wages for tax-credit/deduction estimates.
- **Location:** ZIP **90001** → **Los Angeles, California, Los Angeles County** (South LA / Florence–Firestone area). *State and County were blank on intake; derived from ZIP 90001 (source: LA County DPSS + LADWP service area both confirm 90001).* (verified — ZIP→county)
- **Employment:** Not stated; income level implies employed/working. Relevant to childcare-subsidy and workforce eligibility.
- **Health needs:** 4-year-old has **asthma** — household needs strong **urgent care + ER coverage** and prescription (controller/rescue inhaler) coverage.
- **Current coverage:** **NONE — household is uninsured.** This is urgent given the child's asthma.
- **Special circumstances:** Single-parent household with two minor children (one under 6 → LIHEAP priority group; one under 5 → WIC-eligible). No veteran/disability/asset data provided.
- **Key state facts:** California **is a Medicaid-expansion state** (adults ≤138% FPL). (verified)

## Federal Poverty Level Calculation
- **Guidelines used:** 2025 HHS Poverty Guidelines, 48 contiguous states + DC (the basis California's Medi-Cal/CalFresh/CARE FFY2025–26 charts currently apply). (verified against context reference table)
- **100% FPL, household of 3 = $26,650.**
- **Math:** $42,000 ÷ $26,650 = **1.576 → 157.6% FPL.** (verified — recompute: 26,650 × 1.576 = 42,000 ✓)
- **Where this household lands on key thresholds (household of 3):**
  | FPL % | Annual $ | What it gates | This family ($42,000 = 157.6%) |
  |---|---|---|---|
  | 100% | $26,650 | Head Start income line | Above |
  | **138%** | **$36,777** | Adult Medi-Cal (expansion) ceiling | **Above → parent uses Covered California, not Medi-Cal** |
  | 150% | $39,975 | Enhanced Silver 94 / CA-subsidy $0 tier | Above |
  | **157.6%** | **$42,000** | — | **← YOU ARE HERE** |
  | **165%** | **$43,972** | CA State Premium Subsidy ceiling | **Just below (4.5%) → CLIFF, see warnings** |
  | 185% | $49,303 | WIC | Below → eligible |
  | 200% | $53,300 | CalFresh gross / CARE utility | Below → eligible |
  | 266% | $70,889 | Children's Medi-Cal ceiling | Well below → both kids free Medi-Cal |
  | 400% | $106,600 | ACA subsidy cliff | Well below |
- *Note: 2026 HHS guidelines may now apply to some programs; the CA program charts cited below are the current effective (FFY2025–26 / June-2025) editions. The 157.6% result and all threshold conclusions hold under both.*

## Programs Found

### Healthcare
| Program (CA name) | Agency | Eligibility Summary | Income Limit (HH of 3) | Est. Monthly Value | Source URL | Enrollment Window |
|---|---|---|---|---|---|---|
| **Medi-Cal for Children (kids 4 & 9)** | CA DHCS (Medicaid) | Children ≤266% FPL qualify **free, full-scope**. Covers asthma: ER, urgent care, specialists, inhalers, $0 copay. **Entitlement — guaranteed if eligible.** Both kids qualify. | ≤$70,889/yr (266% FPL); family far below | **~$500/mo** total both kids (est.) | dhcs.ca.gov/medi-cal/qualify/qualify-for-medi-cal-eligibility-chart · apply: benefitscal.com | **Year-round (no open enrollment) — apply now** |
| **Covered California + federal premium tax credit / APTC (parent)** | Covered California / IRS | Parent at 157.6% FPL is **over** 138% adult Medi-Cal → marketplace. Eligible for APTC (138–400% FPL) + **cost-sharing reduction "Enhanced Silver 87"** (150–200% FPL, ~87% actuarial value, low deductible). | 138–400% FPL = $36,777–$106,600 | **~$400/mo** premium assistance (est.); net premium ~$110–140/mo | coveredca.com | 2026 OE **CLOSED 1/31/26** → needs Special Enrollment Period now, or 2027 OE 11/1/26–1/31/27 |
| **California State Premium Subsidy (parent)** | Covered California (state) | New 2026 state program (federal enhanced subsidies expired 12/31/25). Enrollees **≤165% FPL**: 150–165% pay only 3.19–3.91% of income toward premium. Family at 157.6% qualifies. | ≤165% FPL = ≤$43,972/yr | (folded into APTC value above; keeps net premium low) (est.) | hbex.coveredca.com/stakeholders/PDFs/2026-02_StatePremiumSub_PolicyExplainer-Final.pdf | 2026 plan year (tied to Covered CA enrollment) |
| **California Children's Services (CCS)** — *marginal* | CA DHCS | Children <21 with eligible chronic/severe conditions get specialty care coordination. **Severe** asthma *may* qualify; mild asthma typically does not. Flag for Eligibility Analyst. | Linked to Medi-Cal (no separate test if enrolled) | Varies (specialty care) (est.) | dhcs.ca.gov/services/ccs | Year-round; depends on asthma severity |

### Food Assistance
| Program (CA name) | Agency | Eligibility Summary | Income Limit (HH of 3) | Est. Monthly Value | Source URL | Enrollment Window |
|---|---|---|---|---|---|---|
| **CalFresh (SNAP)** | CA CDSS / LA County DPSS | CA uses 200% FPL gross limit (broad-based categorical eligibility). Family gross $3,500/mo **passes** gross ($4,442) and net ($2,221) tests. Likely eligible for a modest benefit. | Gross ≤$4,442/mo ($53,304/yr); net ≤$2,221/mo | **~$215/mo** (est.; range $150–350 depending on rent + childcare deductions) | cdss.ca.gov/calfresh · dpss.lacounty.gov/en/food/calfresh.html · apply benefitscal.com | Year-round; **expedited (3-day)** issuance if urgent |
| **WIC (4-year-old)** | CA CDPH / USDA-FNS | Children <5 at ≤185% FPL; **auto-eligible (adjunctive) once on Medi-Cal/CalFresh.** 4-yo qualifies (~1 yr left before age 5). | ≤$49,303/yr (185% FPL) | **~$45/mo** food package (est.) | myfamily.wic.ca.gov · phfewic.org | Year-round |
| **California Universal Meals (free breakfast + lunch)** | CA CDE / USDA | **All** TK–12 public-school students eat free, **no income test** (AB 130 / EC 49501.5). 9-yo qualifies now; 4-yo when in TK. | None (universal) | **~$85/mo** for the 9-yo (est.) | cde.ca.gov/ls/nu/sn/cauniversalmeals.asp | Automatic at school enrollment |

### Housing
| Program (CA name) | Agency | Eligibility Summary | Income Limit (HH of 3) | Est. Monthly Value | Source URL | Enrollment Window |
|---|---|---|---|---|---|---|
| **Section 8 Housing Choice Voucher — HACLA (City of LA)** | HACLA / HUD | ≤50% Area Median Income (~$62,700 for HH of 3, LA). Family likely income-eligible. **Competitive/lottery — not an entitlement.** | ~50% AMI ≈ $62,700/yr | ~$1,500–2,000/mo **IF awarded** (est.) | hacla.org | General HCV waitlist **CLOSED** (lottery closed). **Project-Based Voucher list OPEN as of 7/4/26** — families w/ children prioritized |
| **Section 8 HCV / Public Housing — LACDA (LA County)** | LACDA / HUD | ≤50% AMI. HCV list closed except homeless (Coordinated Entry) referrals. **Public Housing** waitlist has a rare opening window. | ~50% AMI (HH of 3) | Rent capped at 30% of income; subsidy varies **IF awarded** (est.) | lacda.org/section-8 | HCV **CLOSED** (homeless referrals only); **Public Housing waitlist window ~Aug 17–Sep 16, 2026** — verify at lacda.org |

### Utilities & Energy
| Program (CA name) | Agency | Eligibility Summary | Income Limit (HH of 3) | Est. Monthly Value | Source URL | Enrollment Window |
|---|---|---|---|---|---|---|
| **LIHEAP / California HEAP (energy bill help)** | CA CSD → LA County community-action agencies / HHS-ACF | ≤60% State Median Income; **categorically eligible once on CalFresh/CalWORKs.** **Priority group: families with a child under 6 (the 4-yo).** Benefit: heating $94–$1,500 / cooling $283–$932 / crisis ≤$1,500. | ~60% SMI (HH-of-3 = 84% of 4-person SMI); exact $ verify at csd.ca.gov | **~$400 one-time/yr** (~$33/mo equiv) (est.) | csd.ca.gov · 1-866-675-6623 | FFY2026 **Oct 1 2025 – Sep 30 2026**; limited funds + priority plan → **apply ASAP** |
| **CARE — California Alternate Rates for Energy** | CPUC / SoCalGas (gas) + SCE (electric, if in SCE territory) | ≤200% FPL **or** categorical via Medi-Cal/CalFresh/WIC/free school lunch. Family qualifies both ways. Discount ~20% gas + 30–35% electric. | ≤$53,300/yr (200% FPL, thru 5/31/26) | **~$50/mo** savings (est.) | cpuc.ca.gov/care · socalgas.com · sce.com/save-money/income-qualified-programs/care-fera | Year-round |
| **LADWP EZ-SAVE** *(use instead of CARE if LADWP is the electric provider — City of LA)* | LADWP (municipal, not CARE) | Income-qualified LA residents; municipal alternative to CARE for electricity. Not additive to CARE-electric. | See ladwp.com/EZSAVE | ~$10–30/mo bill discount (est.) | ladwp.com/residential-services/assistance-programs/ez-save-program | Year-round |

### Childcare & Education
*(These are largely OVERLAPPING pathways for the 4-yo's early education — not additive. Choose one primary path + wrap-around care.)*
| Program (CA name) | Agency | Eligibility Summary | Income Limit (HH of 3) | Est. Monthly Value | Source URL | Enrollment Window |
|---|---|---|---|---|---|---|
| **Subsidized Child Care — CAPP / General Child Care / CalWORKs Stages** | CA CDSS / LA County Resource & Referral agencies | ≤85% SMI; working single parent w/ kids 4 & 9. Covers preschool for 4-yo + before/after-school for 9-yo. **Slot-limited (Centralized Eligibility List).** | ≤$89,659/yr (85% SMI) | **~$1,000–1,500/mo IF slot obtained** (est.) | cdss.ca.gov/inforesources/child-care-and-development · mychildcare.ca.gov | Year-round; waitlist/eligibility list |
| **California State Preschool Program (CSPP) — 4-yo** | CA CDE / CDSS | Ages 3–4 at ≤85% SMI. 4-yo income-eligible. Free part/full-day preschool. | ≤$89,659/yr (85% SMI) | ~$800–1,100/mo value if enrolled (est.) | cde.ca.gov/sp/cd | Year-round; slot-limited |
| **Transitional Kindergarten (TK) — 4-yo** | CA CDE (public school districts) | Universal for all 4-yos by 2025–26, **no income test** (depends on birthdate cutoff). Free public pre-K. | None (universal) | ~$10,000/yr value (~$830/mo) if eligible by birthdate (est.) | cde.ca.gov/ci/gs/em/kinderinfo.asp · LAUSD district | Enroll for 2026–27 school year via local district |
| **Head Start / Early Head Start (4-yo)** — *marginal* | HHS-ACF via LA County grantees (e.g., CCRC) | Ages 3–5 at ≤100% FPL. Family is **over income** BUT may qualify **categorically** (if on CalFresh) or via 10%-over-income slots / child disability. | ≤$26,650/yr (100% FPL) or categorical | ~$10,000/yr value if enrolled (est.) | headstart.gov · eclkc.ohs.acf.hhs.gov/center-locator | Year-round; **apply by Feb for Sept**; marginal |

### Workforce & Training
| Program (CA name) | Agency | Eligibility Summary | Income Limit (HH of 3) | Est. Monthly Value | Source URL | Enrollment Window |
|---|---|---|---|---|---|---|
| **WIOA Adult Services — America's Job Centers of California (AJCC / WorkSource)** | US DOL via LA County WDACS + City of LA EWDD | Adults; low-income get priority of service. **Free** career counseling, skills training, and job placement. | Low-income priority (family qualifies) | Free services (no direct cash; potential earnings gain) | edd.ca.gov/en/jobs_and_training · careeronestop.org | Year-round |

### Other
| Program (CA name) | Agency | Eligibility Summary | Income Limit (HH of 3) | Est. Monthly Value | Source URL | Enrollment Window |
|---|---|---|---|---|---|---|
| **Federal Earned Income Tax Credit (EITC)** | IRS | Head of household + 2 kids, earned income < $57,310 (TY2025). Family is in phase-out zone. **Fully refundable.** | < $57,310/yr | **~$269/mo equiv (~$3,224/yr)** (est.) | irs.gov/credits-deductions/individuals/earned-income-tax-credit-eitc | File 2025 return (was due 4/15/26 — file now if unfiled); TY2026 in early 2027 |
| **Federal Child Tax Credit (CTC / ACTC)** | IRS | 2 kids under 17; $2,200/child, up to $1,700/child refundable via Additional CTC. | Phase-out starts >$200,000 (HoH) | **~$367/mo equiv (~$4,400/yr)**, ~$3,400 refundable (est.) | irs.gov/credits-deductions/individuals/child-tax-credit | File annually with return |
| **California LifeLine (phone / internet discount)** | CPUC | Categorical via Medi-Cal/CalFresh, or income ≤ ~200% FPL. Family qualifies. | Program-based or ≤ ~$53,300/yr | **~$19/mo (~$228/yr)** (est.) | californialifeline.com | Year-round |
| **VITA — Free Tax Preparation** | IRS | Income ≤ ~$67,000. Free help to claim EITC/CTC correctly. | ≤ ~$67,000/yr | Free service | irs.gov/individuals/free-tax-return-preparation-for-qualifying-taxpayers | Jan–Apr each year |
| **CalEITC + Young Child Tax Credit** — ❌ **NOT eligible** | CA FTB | CalEITC caps at ~$31,950 income; family at $42,000 is **over**. YCTC requires CalEITC eligibility → also out. Flagged so Eligibility Analyst confirms. | ≤ ~$31,950/yr | $0 (ineligible unless income drops) | ftb.ca.gov/file/personal/credits/california-earned-income-tax-credit.html | N/A |

## Total Estimated Value
**Total estimated annual value of readily-accessible programs: ~$23,800/year (~$1,983/month).**

Core breakdown (est.): Medi-Cal 2 kids ~$6,000 + Covered CA premium assistance ~$4,800 + CalFresh ~$2,580 + WIC ~$540 + universal school meals (9-yo) ~$1,000 + LIHEAP ~$400 + CARE utility discount ~$600 + California LifeLine ~$228 + federal EITC ~$3,224 + federal CTC ~$4,400 = **~$23,772/yr.**

**Including contingent high-value programs (subject to slot/waitlist availability): subsidized child care/preschool (~$12,000/yr) and a housing voucher (~$18,000/yr) → potential total up to ~$53,800/year.** These are excluded from the headline figure because access depends on open waitlists/available slots, not entitlement.

*All dollar values are ESTIMATES from documented benefit tables/formulas and are labeled (est.); actual amounts require the Eligibility Analyst's verification and the household's specific rent, childcare costs, and exact ages/birthdates.*

## Income Cliff Warnings
1. **⚠️ CA State Premium Subsidy cliff at 165% FPL = $43,972/yr (HH of 3).** Family at $42,000 (157.6%) is only **$1,972 below** the cutoff — **within 4.5%.** If income rises above **$43,972**, the parent **loses the California state premium subsidy** and pays the full 2026 federal contribution, raising the monthly premium. **Value at risk: ~$1,000–1,500/yr** in premium assistance. A raise or extra hours could trigger this — plan around it.
2. **Federal EITC phase-out (gradual, not a hard cliff):** for HoH + 2 kids the credit shrinks from $23,350 up to $57,310. At $42,000 the family loses **~21¢ of EITC per extra $1 earned** (~40% effective marginal rate with payroll tax). Higher earnings still net positive, but the credit erodes.
3. **Parent's Medi-Cal boundary at 138% FPL = $36,777 (reverse note):** family is 14.2% above (outside the 10% zone). **If income *drops* below $36,777, the parent qualifies for FREE Medi-Cal** (no premium) instead of a Covered California plan — worth re-checking if hours are cut.
4. **No cliff risk** for children's Medi-Cal (ceiling $70,889 — far above), WIC ($49,303), CalFresh gross ($53,304), or CARE ($53,300): all have comfortable buffers, and most also grant categorical eligibility once on Medi-Cal/CalFresh.

## Time-Sensitive Programs
1. **🔴 Medi-Cal for both kids — apply NOW (year-round, no deadline, but urgent).** Household is uninsured and the 4-yo has asthma; Medi-Cal is $0 and covers ER/urgent care/inhalers immediately. Apply at **benefitscal.com** or LA County DPSS (866) 613-3777. This is the #1 action.
2. **🔴 Covered California for the parent — 2026 Open Enrollment CLOSED (ended 1/31/2026).** As of July 2026 the parent needs a **Special Enrollment Period** (qualifying life event) to enroll mid-year; otherwise 2027 Open Enrollment is **Nov 1, 2026 – Jan 31, 2027.** Check SEP eligibility at coveredca.com now.
3. **🟠 LIHEAP / HEAP — FFY2026 runs Oct 1, 2025 – Sep 30, 2026 (~2 months left) with limited funds and a priority plan.** Family is in the priority group (child under 6). Apply ASAP before funds are exhausted: csd.ca.gov / 1-866-675-6623.
4. **🟠 LACDA Public Housing waitlist window ~Aug 17 – Sep 16, 2026** (rare opening; verify exact dates at lacda.org). **HACLA Project-Based Voucher list is OPEN as of 7/4/2026** and prioritizes families with children — apply while open (hacla.org).
5. **🟡 Head Start (4-yo):** applications for September enrollment are best submitted by **February**; for Sept 2026 that window has passed — apply now for waitlist/mid-year openings.
6. **🟡 Federal EITC + CTC (~$7,600 combined refundable) for tax year 2025:** the return was due **April 15, 2026** — if not yet filed, file immediately (late refund claims are still allowed) using free VITA help.
