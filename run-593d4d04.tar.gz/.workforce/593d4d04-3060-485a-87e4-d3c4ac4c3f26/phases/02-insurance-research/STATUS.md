## STATUS: COMPLETE
## SUMMARY: <!-- FILL: e.g., "12 plans compared across 4 channels" -->

## Subsidy Eligibility
<!-- FILL: APTC amount, CSR eligibility, FPL %, Medicaid gap status -->

## ACA Marketplace Plans
<!-- FILL: table with Plan Name | Metal Tier | Premium (Before/After Subsidy) | Deductible | OOP Max | Network Type | PCP Copay | Specialist Copay | Urgent Care | ER Copay | Generic Rx | Brand Rx -->

## Off-Marketplace Carrier Plans
<!-- FILL: table with same columns (no subsidy column), or "Not materially different from marketplace options in this area" -->

## Short-Term / Gap Insurance
<!-- FILL: table with Plan | Premium | Duration | Deductible | Key Exclusions -->
### Coverage Limitations Warning
<!-- FILL: explicit list of what short-term plans do NOT cover vs ACA -->

## Health Sharing Ministries
<!-- FILL: table with Organization | Monthly Share | Annual Unshared Amount | Key Limitations -->
### Not Insurance Disclaimer
<!-- FILL: explanation that these are NOT insurance and what that means -->

## Employer Arrangements (ICHRA/QSEHRA)
<!-- FILL: applicability assessment, or "Not applicable — user has no employer coverage option" -->

## Real-World Cost Scenarios
<!-- FILL: table with Plan | Healthy Adult (2 PCP + 1 specialist + 4 Rx) | Family w/ Kids (8 PCP + 2 urgent + 1 ER + 12 Rx) | Chronic Condition (12 specialist + 12 lab + 12 brand Rx) | Worst Case (premiums + OOP max) -->
### Scenario Winner Analysis
<!-- FILL: For each scenario, state which plan wins and by how much, with the copay math shown -->

## Emergency Services Comparison
<!-- FILL: table with Plan | ER Copay | Ambulance | Out-of-Network ER Policy | Waived if Admitted? -->

## Formulary Match
<!-- FILL: table with Medication | Plan A (Tier/Copay) | Plan B (Tier/Copay) | Plan C (Tier/Copay) — or "No medications specified" -->

## Provider Network Match
<!-- FILL: table with Provider | Specialty | Plan A (In/Out) | Plan B (In/Out) | Plan C (In/Out) — or "No providers specified" -->

## Coverage Per Household Member
<!-- FILL: table with Member | Recommended Channel | Plan | Reason -->
